'use strict';

// start the app
require('zone-mta');
