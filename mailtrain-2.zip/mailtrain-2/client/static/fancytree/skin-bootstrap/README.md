The file icons-rtl.gif is assumed by skin-common.less. However skin-bootstrap does not come with icons. 
To avoid errors with webpack an empty file has been provided.