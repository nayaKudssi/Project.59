This is a directory for images uploaded to Mosaico in Mailtrain ver. 1.
Move the content from <project>/public/mosaico/uploads to here (<project>/client/static/mosaico/uploads).
