'use strict';

const anonymousRestrictedAccessToken = 'anonymous';

module.exports = {
    anonymousRestrictedAccessToken
};