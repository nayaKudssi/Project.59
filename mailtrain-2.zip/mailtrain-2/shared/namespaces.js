'use strict';

function getGlobalNamespaceId() {
    return 1;
}

module.exports = {
    getGlobalNamespaceId
};