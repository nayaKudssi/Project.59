'use strict';

function getAdminId() {
    return 1;
}

module.exports = {
    getAdminId
};