'use strict';

const AppType = {
    TRUSTED: 0,
    SANDBOXED: 1,
    PUBLIC: 2
};

module.exports.AppType = AppType;
