'use strict';

import em from '../../ivis-core/client/src/lib/extension-manager';
import './styles.scss';

em.set('app.title', 'Mailtrain IVIS');

require('../../ivis-core/client/src/root-trusted');

