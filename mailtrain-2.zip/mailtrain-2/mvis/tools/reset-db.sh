#!/bin/sh

sudo mysql -e 'drop database mt_ivis; create database mt_ivis; connect mt_ivis'
