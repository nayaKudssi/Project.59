#!/bin/sh

sudo mysql -e 'drop database mvis; create database mvis'
