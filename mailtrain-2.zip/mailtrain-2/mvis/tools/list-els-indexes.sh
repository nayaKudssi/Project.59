#!/bin/sh

curl -X GET "localhost:9200/_cat/indices?v"
