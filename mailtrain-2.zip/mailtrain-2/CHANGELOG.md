# Changelog

## 2.0.0-rc1 2018-12-25

  * This is a complete rewrite of Mailtrain v1 with many features added. Just check it out.
